import asyncio
import io
import discord
from discord import app_commands
from discord.ext import commands

import cards as cards_mod
import campo as campo_mod
from config import MAX_TITULARES, FORMACOES, FORMACAO_PADRAO
from utils import montar_embed_carta


def encontrar_instancia(lista, nome):
    nome = nome.lower()
    for item in lista:
        if item['nome'].lower() == nome:
            return item
    return None


class Elenco(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    @app_commands.command(name="elenco", description="Mostra o elenco titular")
    async def elenco(self, interaction: discord.Interaction, usuario: discord.Member = None):
        await interaction.response.defer()  # gerar a imagem pode passar de 3s; isso libera até 15min

        alvo = usuario or interaction.user
        user = await self.db.get_or_create_user(alvo.id, alvo.name)
        banco = self.db.get_banco(user)
        titulares_ids = self.db.get_titulares_ids(user)
        titulares = [j for j in banco if j['instancia_id'] in titulares_ids]
        reservas = [j for j in banco if j['instancia_id'] not in titulares_ids]
        formacao = user['formacao'] or FORMACAO_PADRAO

        nome_time = user['time_nome'] or f"Time de {alvo.name}"
        sigla = f" [{user['time_sigla']}]" if user['time_sigla'] else ""

        embed = discord.Embed(
            title=f"👥 {nome_time}{sigla}",
            description=(
                f"Formação: **{formacao}** · Titulares: **{len(titulares)}/{campo_mod.total_slots(formacao)}** "
                f"· Reservas: **{len(reservas)}**"
            ),
            color=discord.Color.blue()
        )

        if titulares:
            texto = "\n".join(f"• **{j['nome']}** ({j['posicao']}) — {j['overall']} OVR" for j in titulares)
        else:
            texto = "*Nenhum titular escalado. Use `/promover` para escalar jogadores.*"
        embed.add_field(name="🟢 Titulares", value=texto, inline=False)

        if reservas:
            texto_r = "\n".join(f"• {j['nome']} ({j['posicao']}) — {j['overall']} OVR" for j in reservas[:15])
            if len(reservas) > 15:
                texto_r += f"\n… e mais {len(reservas) - 15}"
        else:
            texto_r = "*Nenhum jogador no banco de reservas.*"
        embed.add_field(name="🔄 Reservas", value=texto_r, inline=False)

        if titulares:
            embed.set_footer(text="Use /formacao pra trocar entre 2-2-2, 3-1-2 e 1-2-3.")
            try:
                # roda o processamento de imagem numa thread separada, pra não travar o loop do bot
                png_bytes = await asyncio.to_thread(campo_mod.gerar_imagem_campo, titulares, formacao)
                arquivo = discord.File(io.BytesIO(png_bytes), filename="campo.png")
                embed.set_image(url="attachment://campo.png")
                await interaction.followup.send(embed=embed, file=arquivo)
            except Exception as e:
                print(f"⚠️ Falha ao gerar imagem do campo: {e}")
                await interaction.followup.send(embed=embed)
        else:
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="carta", description="Mostra a carta de um jogador do seu elenco")
    async def carta(self, interaction: discord.Interaction, nome: str):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        banco = self.db.get_banco(user)
        instancia = encontrar_instancia(banco, nome)
        if not instancia:
            await interaction.response.send_message(f"❌ Você não tem **{nome}** no elenco.", ephemeral=True)
            return

        jogador = cards_mod.get_jogador_por_id(instancia['player_id'])
        if not jogador:
            await interaction.response.send_message("❌ Dados do jogador não encontrados no banco.", ephemeral=True)
            return

        embed, file = montar_embed_carta(
            jogador, instancia['player_id'],
            titulo="🎴 Sua Carta", autor_nome=interaction.user.name
        )
        if file:
            await interaction.response.send_message(embed=embed, file=file)
        else:
            await interaction.response.send_message(embed=embed)

    @app_commands.command(name="vercarta", description="Visualiza a carta de um jogador de qualquer usuário")
    async def vercarta(self, interaction: discord.Interaction, usuario: discord.Member, nome: str):
        user = await self.db.get_or_create_user(usuario.id, usuario.name)
        banco = self.db.get_banco(user)
        instancia = encontrar_instancia(banco, nome)
        if not instancia:
            await interaction.response.send_message(
                f"❌ **{usuario.name}** não tem **{nome}** no elenco.", ephemeral=True
            )
            return

        jogador = cards_mod.get_jogador_por_id(instancia['player_id'])
        if not jogador:
            await interaction.response.send_message("❌ Dados do jogador não encontrados no banco.", ephemeral=True)
            return

        embed, file = montar_embed_carta(
            jogador, instancia['player_id'],
            titulo="🎴 Carta de Jogador", autor_nome=f"Elenco de {usuario.name}"
        )
        if file:
            await interaction.response.send_message(embed=embed, file=file)
        else:
            await interaction.response.send_message(embed=embed)

    @app_commands.command(name="promover", description="Promove um jogador para titular")
    async def promover(self, interaction: discord.Interaction, nome: str):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        banco = self.db.get_banco(user)
        titulares_ids = self.db.get_titulares_ids(user)
        formacao = user['formacao'] or FORMACAO_PADRAO

        instancia = encontrar_instancia(banco, nome)
        if not instancia:
            await interaction.response.send_message(f"❌ Você não tem **{nome}** no elenco.", ephemeral=True)
            return

        if instancia['instancia_id'] in titulares_ids:
            await interaction.response.send_message(f"⚠️ **{nome}** já é titular.", ephemeral=True)
            return

        titulares_atuais_check = [j for j in banco if j['instancia_id'] in titulares_ids]
        if any(j['nome'].lower() == instancia['nome'].lower() for j in titulares_atuais_check):
            await interaction.response.send_message(
                f"❌ Você já tem **{instancia['nome']}** escalado como titular — não dá pra repetir o mesmo jogador.",
                ephemeral=True
            )
            return

        if len(titulares_ids) >= MAX_TITULARES:
            await interaction.response.send_message(
                f"❌ Seu time já tem **{MAX_TITULARES}** titulares! Use `/reserva` para liberar uma vaga.",
                ephemeral=True
            )
            return

        categoria = campo_mod.posicao_normalizada(instancia['posicao'])
        limite_categoria = 1 if categoria == 'GOL' else FORMACOES[formacao][categoria]
        titulares_atuais = [j for j in banco if j['instancia_id'] in titulares_ids]
        na_categoria = sum(1 for j in titulares_atuais if campo_mod.posicao_normalizada(j['posicao']) == categoria)

        if na_categoria >= limite_categoria:
            await interaction.response.send_message(
                f"❌ Sua formação **{formacao}** só tem espaço pra **{limite_categoria}** titular(es) de **{categoria}**. "
                f"Use `/reserva` pra tirar algum ou `/formacao` pra trocar de esquema.",
                ephemeral=True
            )
            return

        titulares_ids.append(instancia['instancia_id'])
        await self.db.update_user(interaction.user.id, titulares=titulares_ids)
        await interaction.response.send_message(f"✅ **{instancia['nome']}** promovido para titular!")

    @app_commands.command(name="reserva", description="Remove um jogador dos titulares para a reserva")
    async def reserva(self, interaction: discord.Interaction, nome: str):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        banco = self.db.get_banco(user)
        titulares_ids = self.db.get_titulares_ids(user)

        instancia = encontrar_instancia(banco, nome)
        if not instancia:
            await interaction.response.send_message(f"❌ Você não tem **{nome}** no elenco.", ephemeral=True)
            return

        if instancia['instancia_id'] not in titulares_ids:
            await interaction.response.send_message(f"⚠️ **{nome}** já está na reserva.", ephemeral=True)
            return

        titulares_ids.remove(instancia['instancia_id'])
        await self.db.update_user(interaction.user.id, titulares=titulares_ids)
        await interaction.response.send_message(f"✅ **{instancia['nome']}** voltou para a reserva!")


async def setup(bot):
    await bot.add_cog(Elenco(bot))
