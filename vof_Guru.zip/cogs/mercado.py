import io
import random
import uuid
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timedelta

import cards as cards_mod
import campo as campo_mod
import sorte as sorte_mod
from config import (
    OBTER_COOLDOWN_SEGUNDOS, FORMACOES, FORMACAO_PADRAO,
    CANAL_RARAS, RARIDADES_ANUNCIADAS, PACOTES,
)
from utils import montar_embed_carta, formatar_dinheiro


def nova_instancia(player_id, jogador):
    return {
        "instancia_id": uuid.uuid4().hex[:10],
        "player_id": player_id,
        "nome": jogador['nome'],
        "posicao": jogador['posicao'],
        "overall": jogador['overall'],
    }


class ComprarSelect(discord.ui.Select):
    def __init__(self, bot, user_id, opcoes_pool):
        self.bot = bot
        self.user_id = user_id
        self.db = bot.db
        options = [
            discord.SelectOption(
                label=f"{info['nome']} · {info['overall']} OVR",
                description=f"{info['posicao']} | {formatar_dinheiro(info['valor_mercado'])}",
                value=pid
            )
            for pid, info in list(opcoes_pool.items())[:25]
        ]
        super().__init__(placeholder="Escolha um jogador para comprar...", options=options)

    async def callback(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id:
            await interaction.response.send_message("❌ Esse mercado não é seu!", ephemeral=True)
            return

        player_id = self.values[0]
        jogador = cards_mod.get_jogador_por_id(player_id)
        if not jogador:
            await interaction.response.send_message("❌ Esse jogador não existe mais.", ephemeral=True)
            return

        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        preco = jogador['valor_mercado']

        if user['saldo'] < preco:
            await interaction.response.send_message(
                f"❌ Saldo insuficiente! Você tem {formatar_dinheiro(user['saldo'])}, "
                f"precisa de {formatar_dinheiro(preco)}.",
                ephemeral=True
            )
            return

        banco = self.db.get_banco(user)
        banco.append(nova_instancia(player_id, jogador))
        await self.db.update_user(interaction.user.id, banco=banco)
        await self.db.add_saldo(interaction.user.id, -preco)
        user = await self.db.get_user(interaction.user.id)

        embed, file = montar_embed_carta(
            jogador, player_id,
            titulo="🛒 Compra Realizada!",
            autor_nome=f"{interaction.user.name} contratou {jogador['nome']}",
            elenco_total=len(banco) + len(self.db.get_titulares_ids(user))
        )
        embed.add_field(name="💰 Saldo restante", value=formatar_dinheiro(user['saldo']), inline=False)
        if file:
            await interaction.response.edit_message(embed=embed, attachments=[file], view=None)
        else:
            await interaction.response.edit_message(embed=embed, view=None)


class ComprarView(discord.ui.View):
    def __init__(self, bot, user_id, opcoes_pool):
        super().__init__(timeout=60)
        self.add_item(ComprarSelect(bot, user_id, opcoes_pool))


class ObterView(discord.ui.View):
    """Botões que aparecem embaixo do resultado do /obter, iguais ao 'Escalar
    como Titular' / 'Vender' da referência: só funcionam pra quem sorteou."""

    def __init__(self, bot, user_id, instancia, jogador):
        super().__init__(timeout=120)
        self.bot = bot
        self.db = bot.db
        self.user_id = user_id
        self.instancia = instancia
        self.jogador = jogador

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if str(interaction.user.id) != self.user_id:
            await interaction.response.send_message("❌ Só quem sorteou essa carta pode usar esses botões!", ephemeral=True)
            return False
        return True

    async def _desativar_botoes(self, interaction: discord.Interaction):
        for item in self.children:
            item.disabled = True
        await interaction.message.edit(view=self)

    @discord.ui.button(label="Escalar como Titular", style=discord.ButtonStyle.green, emoji="⬆️")
    async def escalar(self, interaction: discord.Interaction, button: discord.ui.Button):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        banco = self.db.get_banco(user)
        titulares_ids = self.db.get_titulares_ids(user)
        formacao = user['formacao'] or FORMACAO_PADRAO

        if not any(j['instancia_id'] == self.instancia['instancia_id'] for j in banco):
            await interaction.response.send_message("❌ Essa carta não está mais no seu elenco (já deve ter sido vendida).", ephemeral=True)
            return
        if self.instancia['instancia_id'] in titulares_ids:
            await interaction.response.send_message("⚠️ Esse jogador já é titular.", ephemeral=True)
            return

        titulares_atuais_check = [j for j in banco if j['instancia_id'] in titulares_ids]
        if any(j['nome'].lower() == self.instancia['nome'].lower() for j in titulares_atuais_check):
            await interaction.response.send_message(
                f"❌ Você já tem **{self.instancia['nome']}** escalado como titular — não dá pra repetir o mesmo jogador.",
                ephemeral=True
            )
            return

        categoria = campo_mod.posicao_normalizada(self.instancia['posicao'])
        limite = 1 if categoria == 'GOL' else FORMACOES[formacao][categoria]
        titulares_atuais = [j for j in banco if j['instancia_id'] in titulares_ids]
        na_categoria = sum(1 for j in titulares_atuais if campo_mod.posicao_normalizada(j['posicao']) == categoria)
        if na_categoria >= limite:
            await interaction.response.send_message(
                f"❌ Sua formação **{formacao}** não tem mais vaga de **{categoria}**. "
                f"Use `/reserva` ou `/formacao` pra abrir espaço.",
                ephemeral=True
            )
            return

        titulares_ids.append(self.instancia['instancia_id'])
        await self.db.update_user(interaction.user.id, titulares=titulares_ids)
        await self._desativar_botoes(interaction)
        await interaction.response.send_message(f"✅ **{self.jogador['nome']}** escalado como titular!", ephemeral=True)

    @discord.ui.button(label="Vender", style=discord.ButtonStyle.red, emoji="❌")
    async def vender(self, interaction: discord.Interaction, button: discord.ui.Button):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        banco = self.db.get_banco(user)
        titulares_ids = self.db.get_titulares_ids(user)

        if not any(j['instancia_id'] == self.instancia['instancia_id'] for j in banco):
            await interaction.response.send_message("❌ Essa carta já não está mais no seu elenco.", ephemeral=True)
            return

        banco = [j for j in banco if j['instancia_id'] != self.instancia['instancia_id']]
        if self.instancia['instancia_id'] in titulares_ids:
            titulares_ids.remove(self.instancia['instancia_id'])

        await self.db.update_user(interaction.user.id, banco=banco, titulares=titulares_ids)
        valor = self.jogador['valor_venda']
        await self.db.add_saldo(interaction.user.id, valor)
        await self._desativar_botoes(interaction)
        await interaction.response.send_message(
            f"💰 **{self.jogador['nome']}** vendido por **{formatar_dinheiro(valor)}**!", ephemeral=True
        )


class Mercado(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    async def _entregar_carta(self, interaction, player_id, jogador, chance, titulo, texto_autor):
        """Lógica comum entre /obter e /buypack: salva a instância no elenco,
        monta o embed com botões e dispara o anúncio de raridade alta."""
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        banco = self.db.get_banco(user)
        instancia = nova_instancia(player_id, jogador)
        banco.append(instancia)
        await self.db.update_user(interaction.user.id, banco=banco)
        titulares = self.db.get_titulares_ids(user)

        raridade = cards_mod.calcular_raridade(jogador['overall'])

        embed, file = montar_embed_carta(
            jogador, player_id,
            titulo=titulo,
            autor_nome=texto_autor,
            chance=chance,
            elenco_total=len(banco) + len(titulares)
        )
        rodape = f"VOF Guru · {datetime.now().strftime('%d/%m/%Y %H:%M')}"
        status_sorte = sorte_mod.status()
        if status_sorte:
            rodape = f"🍀 Evento de Sorte {status_sorte['multiplicador']}x ativo! · {rodape}"
        embed.set_footer(text=rodape)

        view = ObterView(self.bot, str(interaction.user.id), instancia, jogador)

        if file:
            await interaction.followup.send(embed=embed, file=file, view=view)
        else:
            await interaction.followup.send(embed=embed, view=view)

        if raridade['nome'] in RARIDADES_ANUNCIADAS and CANAL_RARAS:
            canal = self.bot.get_channel(CANAL_RARAS)
            if canal:
                img_bytes = cards_mod.carregar_imagem(player_id)
                anuncio = discord.Embed(
                    title=f"{raridade['emoji']} PUXADA {raridade['nome']}!",
                    description=(
                        f"**{interaction.user.mention}** tirou **{jogador['nome']}** "
                        f"({jogador['overall']} OVR)!"
                    ),
                    color=discord.Color.gold()
                )
                if img_bytes:
                    arquivo_anuncio = discord.File(io.BytesIO(img_bytes), filename="carta.png")
                    anuncio.set_image(url="attachment://carta.png")
                    await canal.send(embed=anuncio, file=arquivo_anuncio)
                else:
                    await canal.send(embed=anuncio)

    @app_commands.command(name="obter", description=f"Sorteia um jogador do banco (cooldown: {OBTER_COOLDOWN_SEGUNDOS}s)")
    async def obter(self, interaction: discord.Interaction):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)

        if user['last_obter']:
            ultimo = datetime.fromisoformat(user['last_obter'])
            restante = timedelta(seconds=OBTER_COOLDOWN_SEGUNDOS) - (datetime.now() - ultimo)
            if restante.total_seconds() > 0:
                await interaction.response.send_message(
                    f"⏳ Aguarde **{int(restante.total_seconds()) + 1}s** para sortear de novo!", ephemeral=True
                )
                return

        player_id, jogador, chance = cards_mod.get_jogador_aleatorio()
        if not jogador:
            await interaction.response.send_message(
                "❌ Ainda não há jogadores cadastrados! Peça a um admin para usar `/addplayer`.",
                ephemeral=True
            )
            return

        await interaction.response.defer()
        await self.db.update_user(interaction.user.id, last_obter=datetime.now().isoformat())
        await self._entregar_carta(
            interaction, player_id, jogador, chance,
            titulo="🎁 NOVO REFORÇO CONTRATADO!",
            texto_autor=f"{interaction.user.name} abriu um pacote da liga!"
        )

    @app_commands.command(
        name="cesta_basica",
        description="Receba 7 jogadores aleatórios 85+ de DEF, MEI, GOL/GK e ATA"
    )
    async def cesta_basica(self, interaction: discord.Interaction):
        """Entrega sete jogadores distintos 85+ das posições permitidas."""
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        if user.get('cesta_basica_usada', 0):
            await interaction.response.send_message(
                "❌ Você já usou sua **Cesta Básica**. Ela só pode ser resgatada "
                "uma vez e não fica disponível novamente.",
                ephemeral=True
            )
            return

        pool_elegivel = cards_mod.listar_jogadores_cesta_basica(overall_minimo=85)
        quantidade = 7

        if len(pool_elegivel) < quantidade:
            await interaction.response.send_message(
                "❌ Ainda não há 7 jogadores elegíveis no banco. É preciso ter "
                "7 jogadores distintos com 85+ nas posições DEF, MEI, GOL/GK ou ATA.",
                ephemeral=True
            )
            return

        sorteados = random.sample(list(pool_elegivel.items()), quantidade)
        banco = self.db.get_banco(user)
        banco.extend(nova_instancia(player_id, jogador) for player_id, jogador in sorteados)
        await self.db.update_user(
            interaction.user.id,
            banco=banco,
            cesta_basica_usada=1,
        )

        embed = discord.Embed(
            title="🧺 Cesta Básica Recebida!",
            description=(
                f"{interaction.user.mention}, você recebeu **7 jogadores aleatórios** "
                "com overall **85+**."
            ),
            color=discord.Color.green()
        )
        for indice, (_, jogador) in enumerate(sorteados, start=1):
            embed.add_field(
                name=f"{indice}. {jogador['nome']} — {jogador['overall']} OVR",
                value=f"📍 {jogador['posicao']} · {jogador.get('clube', '—')}",
                inline=False
            )
        total = len(banco) + len(self.db.get_titulares_ids(user))
        embed.set_footer(text=f"Elenco total: {total} jogador(es)")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="buypack", description="Compra um pacote de cartas com chances melhores de raridades altas")
    @app_commands.describe(pack="Qual pacote comprar")
    @app_commands.choices(pack=[
        app_commands.Choice(name=f"{nome} - {formatar_dinheiro(dados['preco'])}", value=nome)
        for nome, dados in PACOTES.items()
    ])
    async def buypack(self, interaction: discord.Interaction, pack: str):
        config_pacote = PACOTES.get(pack)
        if not config_pacote:
            await interaction.response.send_message("❌ Pacote inválido.", ephemeral=True)
            return

        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        preco = config_pacote['preco']
        if user['saldo'] < preco:
            await interaction.response.send_message(
                f"❌ Saldo insuficiente! Você tem {formatar_dinheiro(user['saldo'])}, "
                f"precisa de {formatar_dinheiro(preco)} pro **{pack}**.",
                ephemeral=True
            )
            return

        pesos = sorte_mod.aplicar_multiplicador(config_pacote['pesos'])
        player_id, jogador, chance = cards_mod.sortear_por_pesos(pesos)
        if not jogador:
            await interaction.response.send_message(
                "❌ Ainda não há jogadores cadastrados! Peça a um admin para usar `/addplayer`.",
                ephemeral=True
            )
            return

        await interaction.response.defer()
        await self.db.add_saldo(interaction.user.id, -preco)
        await self._entregar_carta(
            interaction, player_id, jogador, chance,
            titulo=f"📦 {pack} ABERTO!",
            texto_autor=f"{interaction.user.name} comprou um {pack} por {formatar_dinheiro(preco)}!"
        )

    @app_commands.command(name="comprar", description="Abre o mercado de transferências")
    async def comprar(self, interaction: discord.Interaction):
        pool = cards_mod.listar_pool()
        if not pool:
            await interaction.response.send_message("📭 O mercado está vazio no momento.", ephemeral=True)
            return

        embed = discord.Embed(
            title="🏟️ Mercado de Transferências",
            description="Selecione abaixo um jogador para contratar com seu saldo.",
            color=discord.Color.blue()
        )
        view = ComprarView(self.bot, str(interaction.user.id), pool)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Mercado(bot))
