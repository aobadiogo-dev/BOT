from datetime import datetime, timedelta

import discord
from discord import app_commands
from discord.ext import commands

import campeonato as camp_mod
from database import Database
from config import (
    TIPOS_CAMPEONATO, CAMPEONATO_COOLDOWN_MINUTOS,
    DIVISOES_BRASILEIRAO, DIVISAO_PADRAO,
)
from cogs.jogo import calcular_forca
from utils import formatar_dinheiro

# qual "peso" de nomes de CPU usar em cada divisão do Brasileirão — times
# grandes na Série A, times menores conforme desce de divisão
POOL_POR_DIVISAO = {
    'A': camp_mod.NOMES_ELITE,
    'B': camp_mod.NOMES_MEIO,
    'C': camp_mod.NOMES_MENOR,
    'D': camp_mod.NOMES_REGIONAL,
}


def _verificar_cooldown(user, chave):
    """Retorna None se pode jogar, ou uma string com o tempo restante se não pode."""
    cds = Database.get_campeonatos_cd(user)
    ultimo = cds.get(chave)
    if not ultimo:
        return None
    passado = datetime.now() - datetime.fromisoformat(ultimo)
    restante = timedelta(minutes=CAMPEONATO_COOLDOWN_MINUTOS) - passado
    if restante.total_seconds() <= 0:
        return None
    m, s = divmod(int(restante.total_seconds()), 60)
    return f"{m}min {s}s"


def _formatar_grupos(relatorio):
    """Monta um único bloco de texto com os jogos de cada grupo, com cabeçalho —
    fica mais organizado do que jogar tudo junto sem separação."""
    blocos = [f"**{grupo['nome']}**\n{grupo['resultados']}" for grupo in relatorio['grupos']]
    return "\n\n".join(blocos)


RECOPA_NOME = "Recopa Sul-Americana"
# se você ganha esse título aqui, fica valendo uma vaga na Recopa contra o
# campeão do outro torneio
TITULOS_QUE_DAO_RECOPA = {"Libertadores", "Sul-Americana"}


class Campeonato(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    @app_commands.command(name="campeonato", description="Joga um campeonato inteiro contra times da CPU")
    @app_commands.describe(tipo="Qual campeonato disputar")
    @app_commands.choices(tipo=[
        app_commands.Choice(
            name=f"{nome} — {dados['overall_min']}-{dados['overall_max']} OVR | prêmio {formatar_dinheiro(dados['premio'])}",
            value=nome
        )
        for nome, dados in TIPOS_CAMPEONATO.items()
    ])
    async def campeonato(self, interaction: discord.Interaction, tipo: str):
        config_tipo = TIPOS_CAMPEONATO[tipo]
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)

        if tipo == RECOPA_NOME:
            # a Recopa não usa o cooldown normal — ela só libera quando você
            # é campeão da Libertadores ou da Sul-Americana, e é uso único
            if not user.get('recopa_pendente'):
                await interaction.response.send_message(
                    "❌ Você só pode disputar a **Recopa Sul-Americana** sendo campeão da **Libertadores** "
                    "ou da **Sul-Americana** primeiro.",
                    ephemeral=True
                )
                return
        else:
            restante = _verificar_cooldown(user, tipo)
            if restante:
                await interaction.response.send_message(
                    f"⏳ Você já jogou o **{tipo}** recentemente. Espera **{restante}** pra jogar de novo "
                    f"(outros campeonatos podem ser jogados na hora).",
                    ephemeral=True
                )
                return

        titulares, media = calcular_forca(user, self.db)
        if not titulares:
            await interaction.response.send_message(
                "❌ Você precisa ter titulares escalados (`/promover`) pra disputar um campeonato.", ephemeral=True
            )
            return

        await interaction.response.defer()
        nome_time = user['time_nome'] or interaction.user.name

        titulo_defendido = None
        if tipo == RECOPA_NOME:
            titulo_defendido = user['recopa_pendente']  # 'Libertadores' ou 'Sul-Americana'
            await self.db.update_user(interaction.user.id, recopa_pendente=None)  # uso único, consome na hora
        else:
            await self.db.set_campeonato_jogado_agora(interaction.user.id, tipo)

        relatorio = camp_mod.rodar_campeonato_solo(
            nome_time, media, config_tipo,
            pool=[f"Campeão da {('Sul-Americana' if titulo_defendido == 'Libertadores' else 'Libertadores')}"]
            if tipo == RECOPA_NOME else None
        )

        embed = discord.Embed(title=f"🏆 {tipo}", color=discord.Color.gold())

        if tipo == RECOPA_NOME:
            adversario_titulo = "Sul-Americana" if titulo_defendido == "Libertadores" else "Libertadores"
            embed.description = f"Você (campeão da **{titulo_defendido}**) x o campeão da **{adversario_titulo}**"

        if relatorio['grupos']:
            for grupo in relatorio['grupos']:
                embed.add_field(name=f"📋 {grupo['nome']}", value=grupo['tabela'][:1024], inline=True)
            embed.add_field(name="⚽ Fase de Grupos", value=_formatar_grupos(relatorio)[:1024], inline=False)
            embed.add_field(name="🥊 Mata-mata", value=relatorio['mata_mata'][:1024], inline=False)
        else:
            embed.add_field(name="⚽ Resultado", value=relatorio['mata_mata'][:1024], inline=False)

        campeao = relatorio['campeao']
        if relatorio['voce_venceu']:
            await self.db.add_saldo(interaction.user.id, config_tipo['premio'])
            if tipo in TITULOS_QUE_DAO_RECOPA:
                await self.db.update_user(interaction.user.id, recopa_pendente=tipo)
            embed.add_field(
                name="🏆 VOCÊ FOI CAMPEÃO!",
                value=f"Prêmio: **{formatar_dinheiro(config_tipo['premio'])}**"
                      + (f"\n🎟️ Você garantiu vaga na **{RECOPA_NOME}**! Use `/campeonato` de novo pra disputar."
                         if tipo in TITULOS_QUE_DAO_RECOPA else ""),
                inline=False
            )
            embed.color = discord.Color.green()
        else:
            texto_derrota = f"**{campeao['nome_time']}** levou o título dessa vez."
            if tipo == RECOPA_NOME:
                texto_derrota += " Sua vaga na Recopa já foi usada — vença a Libertadores ou a Sul-Americana de novo pra ganhar outra."
            else:
                texto_derrota += f" Tenta de novo em {CAMPEONATO_COOLDOWN_MINUTOS} minutos!"
            embed.add_field(name="😔 Resultado Final", value=texto_derrota, inline=False)
            embed.color = discord.Color.red()

        await interaction.followup.send(embed=embed)

    @app_commands.command(name="brasileirao", description="Disputa a temporada inteira do Brasileirão na sua divisão atual (acesso/queda)")
    async def brasileirao(self, interaction: discord.Interaction):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)

        restante = _verificar_cooldown(user, "Brasileirão")
        if restante:
            await interaction.response.send_message(
                f"⏳ Você já jogou o Brasileirão recentemente. Espera **{restante}** pra jogar de novo.",
                ephemeral=True
            )
            return

        titulares, media = calcular_forca(user, self.db)
        if not titulares:
            await interaction.response.send_message(
                "❌ Você precisa ter titulares escalados (`/promover`) pra disputar o Brasileirão.", ephemeral=True
            )
            return

        divisao = user['divisao_brasileirao'] or DIVISAO_PADRAO
        config_divisao = DIVISOES_BRASILEIRAO[divisao]
        nome_time = user['time_nome'] or interaction.user.name

        await interaction.response.defer()
        await self.db.set_campeonato_jogado_agora(interaction.user.id, "Brasileirão")

        if config_divisao['formato'] == 'copa':
            await self._brasileirao_copa(interaction, user, divisao, config_divisao, nome_time, media)
        else:
            await self._brasileirao_liga(interaction, user, divisao, config_divisao, nome_time, media)

    async def _brasileirao_copa(self, interaction, user, divisao, config_divisao, nome_time, media):
        """Série D: formato de copa (grupos + mata-mata), igual a Série D de verdade —
        só o campeão da chave sobe pra Série C."""
        relatorio = camp_mod.rodar_campeonato_solo(nome_time, media, config_divisao, pool=POOL_POR_DIVISAO.get(divisao))

        embed = discord.Embed(title=f"⚽ Brasileirão — Série {divisao}", color=discord.Color.blue())
        if relatorio['grupos']:
            for grupo in relatorio['grupos']:
                embed.add_field(name=f"📋 {grupo['nome']}", value=grupo['tabela'][:1024], inline=True)
            embed.add_field(name="⚽ Fase de Grupos", value=_formatar_grupos(relatorio)[:1024], inline=False)
        embed.add_field(name="🥊 Mata-mata", value=relatorio['mata_mata'][:1024], inline=False)

        if relatorio['voce_venceu']:
            premio = config_divisao['premio']
            nova_divisao = config_divisao['sobe']
            await self.db.add_saldo(interaction.user.id, premio)
            await self.db.update_user(interaction.user.id, divisao_brasileirao=nova_divisao)
            embed.add_field(
                name="🔼 CAMPEÃO — ACESSO!",
                value=f"Você venceu a Série **{divisao}** e subiu pra Série **{nova_divisao}**!\nPrêmio: **{formatar_dinheiro(premio)}**",
                inline=False
            )
            embed.color = discord.Color.green()
        else:
            embed.add_field(
                name="😔 Não foi dessa vez",
                value=f"**{relatorio['campeao']['nome_time']}** foi o campeão da chave. Você continua na Série **{divisao}**.",
                inline=False
            )
            embed.color = discord.Color.red()

        await interaction.followup.send(embed=embed)

    async def _brasileirao_liga(self, interaction, user, divisao, config_divisao, nome_time, media):
        """Séries C/B/A: pontos corridos de verdade — você + 8 CPU jogam todos
        contra todos, cada confronto uma vez (32 jogos pra cada time). Tabela final decide
        acesso/rebaixamento pela posição, igual futebol de verdade."""
        resultado = camp_mod.rodar_temporada_liga(nome_time, media, config_divisao, pool=POOL_POR_DIVISAO.get(divisao))
        ranking, stats = resultado['ranking'], resultado['stats']
        total = resultado['total_times']

        linhas_tabela = []
        for pos, time in enumerate(ranking, start=1):
            s = stats[time['user_id']]
            marcador = "👉 " if time['user_id'] == 'voce' else "　"
            nome_exibido = f"**{time['nome_time']}**" if time['user_id'] == 'voce' else time['nome_time']
            linhas_tabela.append(
                f"{marcador}{pos}. {nome_exibido} — {s['pontos']} pts "
                f"({s['v']}V {s['e']}E {s['d']}D, saldo {s['gp'] - s['gc']:+d})"
            )

        embed = discord.Embed(
            title=f"⚽ Brasileirão — Série {divisao}",
            description=f"Temporada de {resultado['jogos_por_time']} jogos ({total} times na tabela).",
            color=discord.Color.blue()
        )
        embed.add_field(name="📊 Tabela Final", value="\n".join(linhas_tabela)[:1024], inline=False)

        posicao = resultado['posicao_voce']
        zona_acesso = config_divisao.get('zona_acesso', 0)
        zona_rebaixamento = config_divisao.get('zona_rebaixamento', 0)

        if zona_acesso and posicao <= zona_acesso and config_divisao['sobe']:
            nova_divisao = config_divisao['sobe']
            premio = config_divisao['premio']
            await self.db.add_saldo(interaction.user.id, premio)
            await self.db.update_user(interaction.user.id, divisao_brasileirao=nova_divisao)
            embed.add_field(
                name="🔼 ACESSO!",
                value=f"Você terminou em **{posicao}º** lugar e subiu da Série **{divisao}** pra Série **{nova_divisao}**!\nPrêmio: **{formatar_dinheiro(premio)}**",
                inline=False
            )
            embed.color = discord.Color.green()
        elif zona_rebaixamento and posicao > total - zona_rebaixamento and config_divisao['desce']:
            nova_divisao = config_divisao['desce']
            await self.db.update_user(interaction.user.id, divisao_brasileirao=nova_divisao)
            embed.add_field(
                name="🔽 REBAIXAMENTO!",
                value=f"Você terminou em **{posicao}º** lugar e caiu da Série **{divisao}** pra Série **{nova_divisao}**.",
                inline=False
            )
            embed.color = discord.Color.red()
        else:
            premio_meio_tabela = config_divisao['premio'] // 4
            await self.db.add_saldo(interaction.user.id, premio_meio_tabela)
            embed.add_field(
                name="➖ Meio de Tabela",
                value=f"Você terminou em **{posicao}º** lugar e continua na Série **{divisao}**.\nPrêmio de participação: **{formatar_dinheiro(premio_meio_tabela)}**",
                inline=False
            )
            embed.color = discord.Color.gold()

        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Campeonato(bot))
