import random
import discord
from discord import app_commands
from discord.ext import commands

import campo as campo_mod
import simulacao
from config import TESTMATCH_NIVEIS
from utils import formatar_dinheiro


def calcular_forca(user_row, db):
    banco = db.get_banco(user_row)
    titulares_ids = db.get_titulares_ids(user_row)
    titulares = [j for j in banco if j['instancia_id'] in titulares_ids]
    if not titulares:
        return None, 0
    media = sum(j['overall'] for j in titulares) / len(titulares)
    return titulares, media


def calcular_reservas(user_row, db):
    banco = db.get_banco(user_row)
    titulares_ids = db.get_titulares_ids(user_row)
    return [j for j in banco if j['instancia_id'] not in titulares_ids]


FRASES_GOL = [
    "bate cruzado e não dá chance pro goleiro",
    "cabeceia no canto após cobrança de escanteio",
    "arranca em contra-ataque e finaliza com categoria",
    "aproveita o rebote e empurra pra dentro",
    "manda uma bomba de fora da área",
    "fica na cara do gol e não perdoa",
    "cobra pênalti com categoria",
]

FRASES_CHANCE_PERDIDA = [
    "chuta por cima do gol",
    "finaliza mas o goleiro faz a defesa",
    "isola a bola por pouco",
    "para na trave!",
    "erra o gol livre",
]

FRASES_AMARELO = [
    "leva cartão amarelo por falta dura",
    "é advertido por reclamação com o árbitro",
    "vê o amarelo por perder tempo",
    "recebe cartão por entrada por trás",
]

FRASES_VERMELHO = [
    "é expulso após uma entrada violenta! Time fica com um a menos!",
    "leva vermelho direto por agressão e deixa o time desfalcado!",
    "recebe o segundo amarelo e é expulso de campo!",
]

FRASES_BRIGA = [
    "se estranham após disputa de bola e a confusão generalizada começa!",
    "trocam empurrões no meio-campo e o árbitro precisa separar!",
    "discutem feio depois de uma entrada mais dura!",
]

FRASES_LESAO = [
    "sente a coxa e precisa deixar o campo",
    "torce o tornozelo e passa por atendimento médico",
    "leva uma pancada e fica caído por alguns minutos",
]

FRASES_SUBSTITUICAO = [
    "sai cansado e dá lugar a",
    "é substituído por",
    "sai pra dar uma refrescada no time, entra",
]


def _escolher_jogador(titulares):
    """Prioriza atacante > meia > qualquer um, pra decidir quem fez o gol/a jogada."""
    if not titulares:
        return None
    for categoria in ('ATA', 'MEI'):
        candidatos = [j for j in titulares if campo_mod.posicao_normalizada(j['posicao']) == categoria]
        if candidatos:
            return random.choice(candidatos)['nome']
    return random.choice(titulares)['nome']


def _jogador_qualquer(titulares):
    """Pega qualquer titular (usado em cartão/briga/lesão — não só quem ataca)."""
    if not titulares:
        return None
    return random.choice(titulares)['nome']


def _texto_jogador(nome_time, titulares_time, qualquer=False):
    escolher = _jogador_qualquer if qualquer else _escolher_jogador
    nome_jogador = escolher(titulares_time)
    return f"{nome_jogador} ({nome_time})" if nome_jogador else nome_time


def gerar_eventos(nome_a, titulares_a, gols_a, nome_b, titulares_b, gols_b, reservas_a=None, reservas_b=None):
    """Monta a linha do tempo da partida: gols (definem o placar) + eventos
    extras de narrativa (cartão amarelo/vermelho, briga, lesão, substituição, chance perdida)."""
    eventos = []
    minutos_usados = set()

    def minuto_livre():
        while True:
            m = random.randint(3, 90)
            if m not in minutos_usados:
                minutos_usados.add(m)
                return m

    for _ in range(gols_a):
        eventos.append((minuto_livre(), f"⚽ **GOL!** {_texto_jogador(nome_a, titulares_a)} {random.choice(FRASES_GOL)}!"))
    for _ in range(gols_b):
        eventos.append((minuto_livre(), f"⚽ **GOL!** {_texto_jogador(nome_b, titulares_b)} {random.choice(FRASES_GOL)}!"))

    times = [(nome_a, titulares_a, reservas_a or []), (nome_b, titulares_b, reservas_b or [])]
    tipos_pesos = [
        ('chance_perdida', 30),
        ('cartao_amarelo', 24),
        ('substituicao', 20),
        ('briga', 10),
        ('lesao', 12),
        ('cartao_vermelho', 4),
    ]
    tipos = [t for t, _ in tipos_pesos]
    pesos = [p for _, p in tipos_pesos]

    for _ in range(random.randint(3, 6)):
        tipo = random.choices(tipos, weights=pesos, k=1)[0]
        nome_time, titulares_time, reservas_time = random.choice(times)

        if tipo == 'chance_perdida':
            texto = f"🔸 {_texto_jogador(nome_time, titulares_time)} {random.choice(FRASES_CHANCE_PERDIDA)}."
        elif tipo == 'cartao_amarelo':
            texto = f"🟨 {_texto_jogador(nome_time, titulares_time, qualquer=True)} {random.choice(FRASES_AMARELO)}."
        elif tipo == 'cartao_vermelho':
            texto = f"🟥 {_texto_jogador(nome_time, titulares_time, qualquer=True)} {random.choice(FRASES_VERMELHO)}"
        elif tipo == 'lesao':
            texto = f"🩹 {_texto_jogador(nome_time, titulares_time, qualquer=True)} {random.choice(FRASES_LESAO)}."
        elif tipo == 'substituicao':
            if not titulares_time:
                continue
            quem_sai = random.choice(titulares_time)['nome']
            quem_entra = random.choice(reservas_time)['nome'] if reservas_time else "um reserva"
            texto = f"🔄 **Substituição** ({nome_time})! {quem_sai} {random.choice(FRASES_SUBSTITUICAO)} {quem_entra}."
        else:  # briga — envolve os dois times
            (nome_x, tit_x, _), (nome_y, tit_y, _) = times[0], times[1]
            texto = (
                f"🥊 **CONFUSÃO!** {_texto_jogador(nome_x, tit_x, qualquer=True)} e "
                f"{_texto_jogador(nome_y, tit_y, qualquer=True)} {random.choice(FRASES_BRIGA)}"
            )

        eventos.append((minuto_livre(), texto))

    eventos.sort(key=lambda e: e[0])
    return "\n".join(f"`{minuto}'` {texto}" for minuto, texto in eventos)


class Jogo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    @app_commands.command(name="jogar", description="Simula uma partida contra outro jogador")
    async def jogar(self, interaction: discord.Interaction, oponente: discord.Member):
        if oponente.id == interaction.user.id:
            await interaction.response.send_message("❌ Você não pode jogar contra si mesmo!", ephemeral=True)
            return
        if oponente.bot:
            await interaction.response.send_message("❌ Não dá pra escalar um bot!", ephemeral=True)
            return

        user_a = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        user_b = await self.db.get_or_create_user(oponente.id, oponente.name)

        titulares_a, media_a = calcular_forca(user_a, self.db)
        titulares_b, media_b = calcular_forca(user_b, self.db)

        if not titulares_a:
            await interaction.response.send_message(
                "❌ Você não tem titulares escalados! Use `/promover`.", ephemeral=True
            )
            return
        if not titulares_b:
            await interaction.response.send_message(
                f"❌ **{oponente.name}** ainda não tem titulares escalados.", ephemeral=True
            )
            return

        gols_a, gols_b = simulacao.jogar_partida(media_a, media_b)

        nome_a = user_a['time_nome'] or interaction.user.name
        nome_b = user_b['time_nome'] or oponente.name

        if gols_a > gols_b:
            resultado = f"🏆 **{nome_a}** venceu a partida!"
            cor = discord.Color.green()
        elif gols_b > gols_a:
            resultado = f"🏆 **{nome_b}** venceu a partida!"
            cor = discord.Color.red()
        else:
            resultado = "🤝 A partida terminou empatada!"
            cor = discord.Color.gold()

        narrativa = gerar_eventos(
            nome_a, titulares_a, gols_a, nome_b, titulares_b, gols_b,
            reservas_a=calcular_reservas(user_a, self.db),
            reservas_b=calcular_reservas(user_b, self.db),
        )

        embed = discord.Embed(
            title="⚽ Simulação de Partida",
            description=(
                f"**{nome_a}** {gols_a} x {gols_b} **{nome_b}**\n"
                f"📊 Overall médio: {nome_a} ({media_a:.1f}) vs {nome_b} ({media_b:.1f})\n\n"
                f"{narrativa}\n\n"
                f"{resultado}"
            ),
            color=cor
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="testmatch", description="Joga uma partida de treino contra um time da CPU e ganha recompensa")
    @app_commands.describe(difficulty="Nível de dificuldade da CPU")
    @app_commands.choices(difficulty=[
        app_commands.Choice(
            name=f"{nivel} ({dados['overall']} OVR | {formatar_dinheiro(dados['recompensa'])})",
            value=nivel
        )
        for nivel, dados in TESTMATCH_NIVEIS.items()
    ])
    async def testmatch(self, interaction: discord.Interaction, difficulty: str):
        config_nivel = TESTMATCH_NIVEIS[difficulty]
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        titulares, media_jogador = calcular_forca(user, self.db)

        if not titulares:
            await interaction.response.send_message(
                "❌ Você não tem titulares escalados! Use `/promover`.", ephemeral=True
            )
            return

        media_cpu = config_nivel['overall']
        gols_jogador, gols_cpu = simulacao.jogar_partida(media_jogador, media_cpu)

        nome_time = user['time_nome'] or interaction.user.name
        nome_cpu = f"CPU ({difficulty})"

        if gols_jogador > gols_cpu:
            recompensa = config_nivel['recompensa']
            resultado = f"🏆 **{nome_time}** venceu a CPU! Recompensa: **{formatar_dinheiro(recompensa)}**"
            cor = discord.Color.green()
        elif gols_jogador == gols_cpu:
            recompensa = config_nivel['recompensa'] // 2
            resultado = f"🤝 Empate! Recompensa reduzida: **{formatar_dinheiro(recompensa)}**"
            cor = discord.Color.gold()
        else:
            recompensa = 0
            resultado = "❌ A CPU venceu. Sem recompensa dessa vez."
            cor = discord.Color.red()

        if recompensa:
            await self.db.add_saldo(interaction.user.id, recompensa)

        narrativa = gerar_eventos(
            nome_time, titulares, gols_jogador, nome_cpu, None, gols_cpu,
            reservas_a=calcular_reservas(user, self.db),
        )

        embed = discord.Embed(
            title=f"⚽ Testmatch — {difficulty}",
            description=(
                f"**{nome_time}** {gols_jogador} x {gols_cpu} **{nome_cpu}**\n"
                f"📊 Overall médio: você ({media_jogador:.1f}) vs CPU ({media_cpu})\n\n"
                f"{narrativa}\n\n"
                f"{resultado}"
            ),
            color=cor
        )
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Jogo(bot))
