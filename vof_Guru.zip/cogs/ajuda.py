import discord
from discord import app_commands
from discord.ext import commands


class Ajuda(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Mostra todos os comandos do bot e o que eles fazem")
    async def help_cmd(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📖 Comandos do VOF Guru",
            description="Tudo que você pode usar, separado por categoria.",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="💰 Economia",
            value=(
                "`/saldo` — vê seu dinheiro na liga\n"
                "`/daily` — resgata a recompensa diária\n"
                "`/pay <user> <amount>` — manda dinheiro pra outro usuário (10% de taxa)\n"
            ),
            inline=False
        )

        embed.add_field(
            name="🎴 Cartas",
            value=(
                "`/obter` — sorteia um jogador do banco (tem cooldown)\n"
                "`/buypack <pack>` — compra um pacote (Bronze/Silver/Gold/Diamond) com chances melhores\n"
                "`/comprar` — abre o mercado de transferências pra contratar direto\n"
                "`/carta <nome>` — mostra a carta de um jogador do seu elenco\n"
                "`/vercarta <usuário> <nome>` — vê a carta de um jogador de outra pessoa\n"
            ),
            inline=False
        )

        embed.add_field(
            name="👥 Elenco e Time",
            value=(
                "`/elenco [usuário]` — mostra o campo com os titulares escalados\n"
                "`/promover <nome>` — escala um jogador da reserva pra titular\n"
                "`/reserva <nome>` — tira um jogador dos titulares\n"
                "`/formacao [formacao]` — vê ou troca a formação (2-2-2, 3-1-2, 1-2-3)\n"
                "`/time [nome] [sigla]` — vê ou define o nome/sigla do seu time\n"
                "`/jogar <oponente>` — simula uma partida contra outro jogador\n"
                "`/testmatch <difficulty>` — treino contra a CPU, paga recompensa se vencer\n"
                "`/campeonato <tipo>` — disputa um campeonato inteiro (Copa do Brasil, Libertadores, Sul-Americana, Argentino, estaduais, Recopa) contra times da CPU\n"
                "`/brasileirao` — disputa a temporada na sua série atual (Série D é copa, C/B/A são pontos corridos de 32 jogos) — sobe/desce pela posição\n"
            ),
            inline=False
        )

        embed.add_field(
            name="🛠️ Administração",
            value=(
                "`/addplayer` — adiciona um jogador ao banco global\n"
                "`/deletarplayer` — remove um jogador do banco global\n"
                "`/listaplayers` — lista todos os jogadores do banco\n"
                "`/limpar_duplicatas` — remove cópias duplicadas dos elencos\n"
                "`/setar` — adiciona um jogador direto no elenco de alguém\n"
                "`/sorte [multiplicador]` — ativa evento que multiplica a chance de OURO/LENDÁRIO (1x-4x)\n"
            ),
            inline=False
        )

        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Ajuda(bot))
