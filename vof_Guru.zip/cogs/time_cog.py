import discord
from discord import app_commands
from discord.ext import commands

import campo as campo_mod
from config import FORMACOES, FORMACAO_PADRAO


class TimeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    @app_commands.command(name="time", description="Veja ou defina o nome e sigla do seu time")
    @app_commands.describe(nome="Novo nome do time (opcional)", sigla="Nova sigla, até 4 letras (opcional)")
    async def time_cmd(self, interaction: discord.Interaction, nome: str = None, sigla: str = None):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)

        if nome is None and sigla is None:
            nome_atual = user['time_nome'] or "*ainda não definido*"
            sigla_atual = user['time_sigla'] or "*ainda não definida*"
            embed = discord.Embed(
                title="🛡️ Seu Time",
                description=f"**Nome:** {nome_atual}\n**Sigla:** {sigla_atual}\n\n"
                            "Use `/time nome:<nome> sigla:<sigla>` para definir.",
                color=discord.Color.blue()
            )
            await interaction.response.send_message(embed=embed)
            return

        if sigla and len(sigla) > 4:
            await interaction.response.send_message("❌ A sigla deve ter no máximo 4 caracteres.", ephemeral=True)
            return

        updates = {}
        if nome:
            updates['time_nome'] = nome
        if sigla:
            updates['time_sigla'] = sigla.upper()
        await self.db.update_user(interaction.user.id, **updates)
        user = await self.db.get_user(interaction.user.id)

        embed = discord.Embed(
            title="✅ Time Atualizado!",
            description=f"**Nome:** {user['time_nome'] or '—'}\n**Sigla:** {user['time_sigla'] or '—'}",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="formacao", description="Veja ou mude a formação do seu time (2-2-2, 3-1-2, 1-2-3)")
    @app_commands.describe(formacao="Nova formação — deixe vazio pra só ver a atual")
    @app_commands.choices(formacao=[
        app_commands.Choice(name="2-2-2", value="2-2-2"),
        app_commands.Choice(name="3-1-2", value="3-1-2"),
        app_commands.Choice(name="1-2-3", value="1-2-3"),
    ])
    async def formacao_cmd(self, interaction: discord.Interaction, formacao: str = None):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        atual = user['formacao'] or FORMACAO_PADRAO

        if formacao is None:
            config_atual = FORMACOES[atual]
            embed = discord.Embed(
                title="🧩 Formação do Time",
                description=(
                    f"Formação atual: **{atual}**\n"
                    f"GOL 1 · DEF {config_atual['DEF']} · MEI {config_atual['MEI']} · ATA {config_atual['ATA']}\n\n"
                    "Use `/formacao formacao:<2-2-2 | 3-1-2 | 1-2-3>` pra trocar."
                ),
                color=discord.Color.blue()
            )
            await interaction.response.send_message(embed=embed)
            return

        if formacao == atual:
            await interaction.response.send_message(f"⚠️ Seu time já está na formação **{formacao}**.", ephemeral=True)
            return

        banco = self.db.get_banco(user)
        titulares_ids = self.db.get_titulares_ids(user)
        titulares = [j for j in banco if j['instancia_id'] in titulares_ids]

        limites = {'GOL': 1, **FORMACOES[formacao]}
        contagem = {}
        mantidos = []
        rebaixados = []
        for j in titulares:
            categoria = campo_mod.posicao_normalizada(j['posicao'])
            contagem.setdefault(categoria, 0)
            if contagem[categoria] < limites.get(categoria, 0):
                contagem[categoria] += 1
                mantidos.append(j['instancia_id'])
            else:
                rebaixados.append(j['nome'])

        await self.db.update_user(interaction.user.id, formacao=formacao, titulares=mantidos)

        config_nova = FORMACOES[formacao]
        desc = (
            f"Formação mudou de **{atual}** para **{formacao}**.\n"
            f"GOL 1 · DEF {config_nova['DEF']} · MEI {config_nova['MEI']} · ATA {config_nova['ATA']}"
        )
        if rebaixados:
            desc += f"\n\n⚠️ Voltaram pra reserva (não cabiam mais nessa formação): {', '.join(rebaixados)}"

        embed = discord.Embed(title="✅ Formação Atualizada!", description=desc, color=discord.Color.green())
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(TimeCog(bot))
