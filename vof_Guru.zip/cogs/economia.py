import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timedelta

from config import DAILY_VALOR, DAILY_COOLDOWN_HORAS, TAXA_PAY
from utils import formatar_dinheiro


class Economia(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    @app_commands.command(name="saldo", description="Veja seu saldo na liga")
    async def saldo(self, interaction: discord.Interaction):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        embed = discord.Embed(
            title="💰 Saldo",
            description=f"{interaction.user.mention} tem **{formatar_dinheiro(user['saldo'])}**.",
            color=discord.Color.gold()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="daily", description=f"Resgate R$ {DAILY_VALOR:,.0f} diários (cooldown: {DAILY_COOLDOWN_HORAS}h)")
    async def daily(self, interaction: discord.Interaction):
        user = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)

        if user['last_daily']:
            ultimo = datetime.fromisoformat(user['last_daily'])
            restante = timedelta(hours=DAILY_COOLDOWN_HORAS) - (datetime.now() - ultimo)
            if restante.total_seconds() > 0:
                h, resto = divmod(int(restante.total_seconds()), 3600)
                m = resto // 60
                await interaction.response.send_message(
                    f"⏳ Você já resgatou hoje! Volte em **{h}h {m}min**.", ephemeral=True
                )
                return

        await self.db.add_saldo(interaction.user.id, DAILY_VALOR)
        await self.db.update_user(interaction.user.id, last_daily=datetime.now().isoformat())
        user = await self.db.get_user(interaction.user.id)

        embed = discord.Embed(
            title="💵 Recompensa Diária",
            description=(
                f"Você recebeu **{formatar_dinheiro(DAILY_VALOR)}**!\n"
                f"💰 Saldo atual: **{formatar_dinheiro(user['saldo'])}**"
            ),
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="pay", description=f"Manda dinheiro pra outro usuário (taxa de {int(TAXA_PAY*100)}%)")
    @app_commands.describe(user="Quem vai receber", amount="Quanto enviar (antes da taxa)")
    async def pay(self, interaction: discord.Interaction, user: discord.Member, amount: int):
        if user.id == interaction.user.id:
            await interaction.response.send_message("❌ Você não pode mandar dinheiro pra si mesmo!", ephemeral=True)
            return
        if user.bot:
            await interaction.response.send_message("❌ Não dá pra mandar dinheiro pra um bot!", ephemeral=True)
            return
        if amount <= 0:
            await interaction.response.send_message("❌ O valor precisa ser maior que zero.", ephemeral=True)
            return

        remetente = await self.db.get_or_create_user(interaction.user.id, interaction.user.name)
        if remetente['saldo'] < amount:
            await interaction.response.send_message(
                f"❌ Saldo insuficiente! Você tem {formatar_dinheiro(remetente['saldo'])}.",
                ephemeral=True
            )
            return

        await self.db.get_or_create_user(user.id, user.name)
        taxa = round(amount * TAXA_PAY)
        valor_recebido = amount - taxa

        await self.db.add_saldo(interaction.user.id, -amount)
        await self.db.add_saldo(user.id, valor_recebido)

        embed = discord.Embed(
            title="💸 Transferência Realizada",
            description=(
                f"{interaction.user.mention} mandou **{formatar_dinheiro(amount)}** pra {user.mention}.\n"
                f"Taxa ({int(TAXA_PAY*100)}%): **{formatar_dinheiro(taxa)}**\n"
                f"{user.mention} recebeu: **{formatar_dinheiro(valor_recebido)}**"
            ),
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Economia(bot))
