import io
import uuid
import discord
from discord import app_commands
from discord.ext import commands

import cards as cards_mod
import sorte as sorte_mod


def eh_admin(interaction: discord.Interaction) -> bool:
    return bool(interaction.user.guild_permissions.administrator)


def nova_instancia(player_id, jogador):
    return {
        "instancia_id": uuid.uuid4().hex[:10],
        "player_id": player_id,
        "nome": jogador['nome'],
        "posicao": jogador['posicao'],
        "overall": jogador['overall'],
    }


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    @app_commands.command(name="addplayer", description="[ADM] Adiciona um jogador ao banco")
    @app_commands.describe(
        nome="Nome do jogador", posicao="Posição do jogador", overall="Overall (0-100)",
        clube="Clube do jogador", preco="Valor de mercado (R$)", imagem="URL da imagem da carta"
    )
    @app_commands.choices(posicao=[
        app_commands.Choice(name="GOL", value="GOL"),
        app_commands.Choice(name="DEF", value="DEF"),
        app_commands.Choice(name="MEI", value="MEI"),
        app_commands.Choice(name="ATA", value="ATA"),
    ])
    async def addplayer(self, interaction: discord.Interaction, nome: str, posicao: str,
                         overall: int, clube: str, preco: float, imagem: str):
        if not eh_admin(interaction):
            await interaction.response.send_message("❌ Você precisa ser administrador!", ephemeral=True)
            return
        if not (0 <= overall <= 100):
            await interaction.response.send_message("❌ Overall deve ser entre 0 e 100!", ephemeral=True)
            return
        if preco < 0:
            await interaction.response.send_message("❌ Preço não pode ser negativo!", ephemeral=True)
            return

        await interaction.response.defer()
        sucesso, mensagem, player_id = cards_mod.adicionar_jogador(nome, posicao, overall, clube, preco, imagem)

        if not sucesso:
            await interaction.followup.send(f"❌ {mensagem}")
            return

        embed = discord.Embed(title="✅ Jogador Adicionado!", description=mensagem, color=discord.Color.green())
        embed.add_field(name="Posição", value=posicao)
        embed.add_field(name="Overall", value=str(overall))
        embed.add_field(name="Clube", value=clube)
        embed.add_field(name="Valor de Mercado", value=f"R$ {preco:,.2f}")
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="deletarplayer", description="[ADM] Deleta um jogador do banco")
    async def deletarplayer(self, interaction: discord.Interaction, nome: str):
        if not eh_admin(interaction):
            await interaction.response.send_message("❌ Você precisa ser administrador!", ephemeral=True)
            return

        player_id, jogador = cards_mod.get_jogador_por_nome(nome)
        if not jogador:
            await interaction.response.send_message(f"❌ Jogador **{nome}** não encontrado.", ephemeral=True)
            return

        sucesso, mensagem = cards_mod.deletar_jogador(player_id)
        if sucesso:
            await interaction.response.send_message(f"✅ {mensagem}")
        else:
            await interaction.response.send_message(f"❌ {mensagem}", ephemeral=True)

    @app_commands.command(name="listaplayers", description="[ADM] Lista todos os jogadores do banco")
    async def listaplayers(self, interaction: discord.Interaction):
        if not eh_admin(interaction):
            await interaction.response.send_message("❌ Você precisa ser administrador!", ephemeral=True)
            return

        pool = cards_mod.listar_pool()
        if not pool:
            await interaction.response.send_message("📭 Nenhum jogador cadastrado ainda.", ephemeral=True)
            return

        linhas = [
            f"#{pid} · {info['nome']} ({info['posicao']}) — {info['overall']} OVR — "
            f"{info.get('clube', '—')} — R$ {info['valor_mercado']:,.2f}"
            for pid, info in pool.items()
        ]
        texto = "\n".join(linhas)

        if len(texto) <= 3800:
            embed = discord.Embed(
                title=f"📋 Jogadores no Banco ({len(pool)})",
                description=texto,
                color=discord.Color.blue()
            )
            await interaction.response.send_message(embed=embed)
        else:
            arquivo = discord.File(io.BytesIO(texto.encode('utf-8')), filename="jogadores.txt")
            await interaction.response.send_message(
                f"📋 Lista com {len(pool)} jogadores (muito grande para embed):", file=arquivo
            )

    @app_commands.command(name="limpar_duplicatas", description="[ADM] Remove jogadores duplicados dos elencos")
    async def limpar_duplicatas(self, interaction: discord.Interaction):
        if not eh_admin(interaction):
            await interaction.response.send_message("❌ Você precisa ser administrador!", ephemeral=True)
            return

        await interaction.response.defer()
        usuarios = await self.db.get_all_users()
        total_removidas = 0
        usuarios_afetados = 0

        for user in usuarios:
            banco = self.db.get_banco(user)
            titulares_ids = set(self.db.get_titulares_ids(user))

            vistos = set()
            novo_banco = []
            for instancia in banco:
                pid = instancia['player_id']
                if pid in vistos:
                    total_removidas += 1
                    titulares_ids.discard(instancia['instancia_id'])
                    continue
                vistos.add(pid)
                novo_banco.append(instancia)

            if len(novo_banco) != len(banco):
                usuarios_afetados += 1
                await self.db.update_user(
                    user['user_id'], banco=novo_banco, titulares=list(titulares_ids)
                )

        embed = discord.Embed(
            title="🧹 Limpeza Concluída",
            description=f"Removidas **{total_removidas}** cartas duplicadas de **{usuarios_afetados}** usuário(s).",
            color=discord.Color.green()
        )
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="setar", description="[ADM] Adiciona um jogador ao elenco de um membro")
    async def setar(self, interaction: discord.Interaction, usuario: discord.Member, nome: str):
        if not eh_admin(interaction):
            await interaction.response.send_message("❌ Você precisa ser administrador!", ephemeral=True)
            return

        player_id, jogador = cards_mod.get_jogador_por_nome(nome)
        if not jogador:
            await interaction.response.send_message(f"❌ Jogador **{nome}** não encontrado no banco.", ephemeral=True)
            return

        user = await self.db.get_or_create_user(usuario.id, usuario.name)
        banco = self.db.get_banco(user)
        banco.append(nova_instancia(player_id, jogador))
        await self.db.update_user(usuario.id, banco=banco)

        await interaction.response.send_message(
            f"✅ **{jogador['nome']}** foi adicionado ao elenco de **{usuario.name}**!"
        )

    @app_commands.command(name="sorte", description="[ADM] Ativa um evento de sorte que aumenta a chance de cartas OURO/LENDÁRIO")
    @app_commands.describe(
        multiplicador="Multiplicador (1x desativa o evento). Deixe vazio pra só ver o status atual",
        duracao_minutos="Por quantos minutos o evento fica ativo (padrão: 30)"
    )
    @app_commands.choices(multiplicador=[
        app_commands.Choice(name="1x (desativar evento)", value=1),
        app_commands.Choice(name="2x", value=2),
        app_commands.Choice(name="3x", value=3),
        app_commands.Choice(name="4x", value=4),
    ])
    async def sorte(self, interaction: discord.Interaction, multiplicador: int = None, duracao_minutos: int = 30):
        if not eh_admin(interaction):
            await interaction.response.send_message("❌ Você precisa ser administrador!", ephemeral=True)
            return

        if multiplicador is None:
            status = sorte_mod.status()
            if not status:
                await interaction.response.send_message("🔕 Nenhum evento de sorte ativo no momento.")
            else:
                m, s = divmod(int(status['restante'].total_seconds()), 60)
                await interaction.response.send_message(
                    f"🍀 Evento de sorte **{status['multiplicador']}x** ativo! Termina em **{m}min {s}s**."
                )
            return

        if multiplicador <= 1:
            sorte_mod.desativar()
            await interaction.response.send_message("🔕 Evento de sorte desativado.")
            return

        if duracao_minutos <= 0:
            await interaction.response.send_message("❌ A duração precisa ser maior que zero.", ephemeral=True)
            return

        sorte_mod.ativar(multiplicador, duracao_minutos)
        embed = discord.Embed(
            title="🍀 Evento de Sorte Ativado!",
            description=(
                f"Chance de **OURO** e **LENDÁRIO** multiplicada por **{multiplicador}x** "
                f"no `/obter` e no `/buypack`.\nDura **{duracao_minutos} minutos**."
            ),
            color=discord.Color.gold()
        )
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Admin(bot))
